# Unit Test Report - FE-121: View Analytics Dashboard

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><td><b>Function Code</b></td><td>FE-121</td><td><b>Function Name</b></td><td>View Analytics Dashboard</td></tr>
  <tr><td><b>Created By</b></td><td>Hadi</td><td><b>Executed By</b></td><td>Hadi</td></tr>
  <tr><td><b>Lines of code</b></td><td>~15</td><td><b>Lack of test cases</b></td><td>0</td></tr>
  <tr><td><b>Class Under Test</b></td><td colspan="3"><code>DashboardService.getDashboardStats()</code>, <code>getChartStats(String range)</code>, and <code>getTopStudents(String range)</code></td></tr>
  <tr><td><b>Test requirement</b></td><td colspan="3">Verify dashboard aggregation, chart-range branching, top-student calculations, and safe fallback behavior.</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><th>Passed</th><th>Failed</th><th>Untested</th><th>N/A/B</th><th>Total Test Cases</th></tr>
  <tr><td>5</td><td>0</td><td>0</td><td>1 / 4 / 0</td><td>5</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr class="matrix-head"><th>Section</th><th>Category</th><th>Item</th><th>UTCID01</th><th>UTCID02</th><th>UTCID03</th><th>UTCID04</th><th>UTCID05</th></tr>
  <tr><td rowspan="5" class="matrix-section"><b>Condition</b></td><td rowspan="2"><b>Precondition</b></td><td>Dashboard request is made</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>Dashboard depends on multiple repositories aggregated by dashboard service</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="2"><b>Mock State (Dependencies)</b></td><td>All repository aggregations succeed</td><td>O</td><td>O</td><td>O</td><td></td><td></td></tr>
  <tr><td>Some repository aggregations fail or return no data</td><td></td><td></td><td></td><td>O</td><td>O</td></tr>
  <tr><td rowspan="1"><b>Input</b></td><td>Range parameter is week/month/year or defaulted</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="5" class="matrix-section"><b>Confirm</b></td><td rowspan="3"><b>Return</b></td><td>Dashboard stats DTO aggregates occupancy, users, bookings, and recent items correctly</td><td>O</td><td>O</td><td>O</td><td></td><td></td></tr>
  <tr><td>Chart stats and top students change with range branch</td><td></td><td>O</td><td>O</td><td></td><td></td></tr>
  <tr><td>Empty/fallback zero values are returned safely when data is missing</td><td></td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td rowspan="1"><b>Exception</b></td><td>Aggregation failure is handled through service/controller fallback path</td><td></td><td></td><td></td><td></td><td>O</td></tr>
  <tr><td rowspan="1"><b>Log message / Interaction</b></td><td>Dashboard aggregation is read-only across all repository queries</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="4" class="matrix-section"><b>Result</b></td><td colspan="2">Type (N: Normal, A: Abnormal, B: Boundary)</td><td>N</td><td>A</td><td>A</td><td>A</td><td>A</td></tr>
  <tr><td colspan="2">Passed/Failed</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td></tr>
  <tr><td colspan="2">Executed Date</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td></tr>
  <tr><td colspan="2">Defect ID</td><td></td><td></td><td></td><td></td><td></td></tr>
</table>
