# Unit Test Report - FE-16: Add Librarian

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><td><b>Function Code</b></td><td>FE-16</td><td><b>Function Name</b></td><td>Add Librarian</td></tr>
  <tr><td><b>Created By</b></td><td>Hadi</td><td><b>Executed By</b></td><td>Hadi</td></tr>
  <tr><td><b>Lines of code</b></td><td>~25</td><td><b>Lack of test cases</b></td><td>0</td></tr>
  <tr><td><b>Class Under Test</b></td><td colspan="3"><code>UserService.importUsers(List&lt;ImportUserRequest&gt; requests)</code></td></tr>
  <tr><td><b>Test requirement</b></td><td colspan="3">Verify librarian creation through bulk user import logic, duplicate validation, default password setup, and user-setting creation.</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><th>Passed</th><th>Failed</th><th>Untested</th><th>N/A/B</th><th>Total Test Cases</th></tr>
  <tr><td>6</td><td>0</td><td>0</td><td>1 / 5 / 0</td><td>6</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr class="matrix-head"><th>Section</th><th>Category</th><th>Item</th><th>UTCID01</th><th>UTCID02</th><th>UTCID03</th><th>UTCID04</th><th>UTCID05</th><th>UTCID06</th></tr>
  <tr><td rowspan="8" class="matrix-section"><b>Condition</b></td><td rowspan="2"><b>Precondition</b></td><td>Import request list is provided</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>Default password encoding is available</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="3"><b>Mock State (Dependencies)</b></td><td>All uniqueness checks pass</td><td>O</td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td>Email or userCode already exists</td><td></td><td></td><td>O</td><td>O</td><td></td><td></td></tr>
  <tr><td>UserSetting save fails after user save</td><td></td><td></td><td></td><td></td><td>O</td><td>O</td></tr>
  <tr><td rowspan="3"><b>Input</b></td><td>Role is LIBRARIAN with valid required fields</td><td>O</td><td></td><td>O</td><td></td><td>O</td><td></td></tr>
  <tr><td>Missing required fields</td><td></td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td>Duplicate email or code</td><td></td><td></td><td></td><td>O</td><td></td><td>O</td></tr>
  <tr><td rowspan="6" class="matrix-section"><b>Confirm</b></td><td rowspan="2"><b>Return</b></td><td>Successful entry contains saved user id, code, email, and full name</td><td>O</td><td></td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td>Failed entry contains import reason for invalid row</td><td></td><td>O</td><td>O</td><td>O</td><td></td><td>O</td></tr>
  <tr><td rowspan="2"><b>Exception</b></td><td>Required-field validation failure is recorded in failed list</td><td></td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td>Duplicate validation failure is recorded in failed list</td><td></td><td></td><td>O</td><td>O</td><td></td><td>O</td></tr>
  <tr><td rowspan="2"><b>Log message / Interaction</b></td><td><code>userRepository.save()</code> is called for valid librarian rows</td><td>O</td><td></td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td><code>userSettingRepository.saveAndFlush()</code> is attempted after user creation</td><td>O</td><td></td><td></td><td></td><td>O</td><td>O</td></tr>
  <tr><td rowspan="4" class="matrix-section"><b>Result</b></td><td colspan="2">Type (N: Normal, A: Abnormal, B: Boundary)</td><td>N</td><td>A</td><td>A</td><td>A</td><td>A</td><td>A</td></tr>
  <tr><td colspan="2">Passed/Failed</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td></tr>
  <tr><td colspan="2">Executed Date</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td></tr>
  <tr><td colspan="2">Defect ID</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
</table>
