# Unit Test Report - FE-14: Import Student via File

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><td><b>Function Code</b></td><td>FE-14</td><td><b>Function Name</b></td><td>Import Student via File</td></tr>
  <tr><td><b>Created By</b></td><td>Hadi</td><td><b>Executed By</b></td><td>Hadi</td></tr>
  <tr><td><b>Lines of code</b></td><td>~40</td><td><b>Lack of test cases</b></td><td>0</td></tr>
  <tr><td><b>Class Under Test</b></td><td colspan="3"><code>AsyncImportService.startImport(MultipartFile file)</code> and <code>processImportAsync(UUID batchId)</code></td></tr>
  <tr><td><b>Test requirement</b></td><td colspan="3">Verify Excel import job creation, validation kickoff, async processing, and failure handling at backend service level.</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><th>Passed</th><th>Failed</th><th>Untested</th><th>N/A/B</th><th>Total Test Cases</th></tr>
  <tr><td>6</td><td>0</td><td>0</td><td>1 / 5 / 0</td><td>6</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr class="matrix-head"><th>Section</th><th>Category</th><th>Item</th><th>UTCID01</th><th>UTCID02</th><th>UTCID03</th><th>UTCID04</th><th>UTCID05</th><th>UTCID06</th></tr>
  <tr><td rowspan="8" class="matrix-section"><b>Condition</b></td><td rowspan="2"><b>Precondition</b></td><td>Excel file is provided</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>Import job repository and staging pipeline are available</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="3"><b>Mock State (Dependencies)</b></td><td><code>parseExcelStreaming()</code> returns row count</td><td>O</td><td>O</td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td><code>parseExcelStreaming()</code> throws parsing exception</td><td></td><td></td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td><code>stagingService.importValidUsers()</code> throws processing exception</td><td></td><td></td><td></td><td>O</td><td></td><td>O</td></tr>
  <tr><td rowspan="3"><b>Input</b></td><td>Valid .xlsx file</td><td>O</td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td>Empty or invalid Excel content</td><td></td><td></td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td>Async processing crashes after job creation</td><td></td><td></td><td></td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="6" class="matrix-section"><b>Confirm</b></td><td rowspan="2"><b>Return</b></td><td>Returns batch id and records total parsed rows</td><td>O</td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td>Completes async import and marks job completed</td><td></td><td></td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td rowspan="2"><b>Exception</b></td><td>Propagates parsing exception from start phase</td><td></td><td></td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td>Marks job failed when async processing throws</td><td></td><td></td><td></td><td>O</td><td></td><td>O</td></tr>
  <tr><td rowspan="2"><b>Log message / Interaction</b></td><td><code>jobRepository.save()</code> is called for job creation and row count update</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td><code>stagingService.validateStagingData()</code> and import hooks are triggered once in async flow</td><td></td><td></td><td></td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="4" class="matrix-section"><b>Result</b></td><td colspan="2">Type (N: Normal, A: Abnormal, B: Boundary)</td><td>N</td><td>N</td><td>A</td><td>A</td><td>A</td><td>A</td></tr>
  <tr><td colspan="2">Passed/Failed</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td></tr>
  <tr><td colspan="2">Executed Date</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td></tr>
  <tr><td colspan="2">Defect ID</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
</table>
