# Unit Test Report - FE-08: View History of Activities

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><td><b>Function Code</b></td><td>FE-08</td><td><b>Function Name</b></td><td>FE-08_View History of Activities</td></tr>
  <tr><td><b>Created By</b></td><td>Hadi</td><td><b>Executed By</b></td><td>Hadi</td></tr>
  <tr><td><b>Lines of code</b></td><td>~20</td><td><b>Lack of test cases</b></td><td>0</td></tr>
  <tr><td><b>Class Under Test</b></td><td colspan="3">`ActivityService.getActivitiesByUser(UUID userId)`, `getTotalStudyHours(UUID userId)`, and `getTotalVisits(UUID userId)`</td></tr>
  <tr><td><b>Test requirement</b></td><td colspan="3">Verify activity-history retrieval and summary calculations from repository dependencies at backend service level.</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><th>Passed</th><th>Failed</th><th>Untested</th><th>N/A/B</th><th>Total Test Cases</th></tr>
  <tr><td>4</td><td>0</td><td>0</td><td>1 / 3 / 0</td><td>4</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr style="background: #001a8d; color: #ffffff;"><th>Section</th><th>Category</th><th>Item</th><th>UTCID01</th><th>UTCID02</th><th>UTCID03</th><th>UTCID04</th></tr>
  <tr><td rowspan="8" style="background: #001a8d; color: #ffffff;"><b>Condition</b></td><td rowspan="2"><b>Precondition</b></td><td>User id is provided</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>History summary depends on activity, access-log, and reservation repositories</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="3"><b>Mock State (Dependencies)</b></td><td>Repositories return activity list, study minutes, and visit count</td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td>Activity repository returns empty result list</td><td></td><td>O</td><td></td><td></td></tr>
  <tr><td>Summary repository calls throw runtime failure</td><td></td><td></td><td>O</td><td>O</td></tr>
  <tr><td rowspan="2"><b>Input</b></td><td>User has activity history</td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td>User has no history records</td><td></td><td>O</td><td></td><td></td></tr>
  <tr><td rowspan="6" style="background: #001a8d; color: #ffffff;"><b>Confirm</b></td><td rowspan="2"><b>Return</b></td><td>Activities are returned in descending time order from repository</td><td>O</td><td>O</td><td></td><td></td></tr>
  <tr><td>Total study hours and visit count are calculated from repository values</td><td>O</td><td>O</td><td></td><td></td></tr>
  <tr><td rowspan="2"><b>Exception</b></td><td>Repository failure in study-hour calculation is propagated</td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td>Repository failure in visit-count calculation is propagated</td><td></td><td></td><td></td><td>O</td></tr>
  <tr><td rowspan="2"><b>Log message / Interaction</b></td><td>`findByUserIdOrderByCreatedAtDesc()` is called once per history request</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>No write operation is executed during history retrieval</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="4" style="background: #001a8d; color: #ffffff;"><b>Result</b></td><td colspan="2">Type (N: Normal, A: Abnormal, B: Boundary)</td><td>N</td><td>A</td><td>A</td><td>A</td></tr>
  <tr><td colspan="2">Passed/Failed</td><td>P</td><td>P</td><td>P</td><td>P</td></tr>
  <tr><td colspan="2">Executed Date</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td></tr>
  <tr><td colspan="2">Defect ID</td><td></td><td></td><td></td><td></td></tr>
</table>
