# Unit Test Report - FE-62: Booking Seat

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><td><b>Function Code</b></td><td>FE-62</td><td><b>Function Name</b></td><td>Booking Seat</td></tr>
  <tr><td><b>Created By</b></td><td>Hadi</td><td><b>Executed By</b></td><td>Hadi</td></tr>
  <tr><td><b>Lines of code</b></td><td>~25</td><td><b>Lack of test cases</b></td><td>0</td></tr>
  <tr><td><b>Class Under Test</b></td><td colspan="3"><code>BookingService.createBooking(UUID userId, Integer seatId, LocalDateTime startTime, LocalDateTime endTime)</code></td></tr>
  <tr><td><b>Test requirement</b></td><td colspan="3">Verify seat booking creation, rule validation, overlap detection, and reservation persistence.</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><th>Passed</th><th>Failed</th><th>Untested</th><th>N/A/B</th><th>Total Test Cases</th></tr>
  <tr><td>7</td><td>0</td><td>0</td><td>1 / 6 / 0</td><td>7</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr class="matrix-head"><th>Section</th><th>Category</th><th>Item</th><th>UTCID01</th><th>UTCID02</th><th>UTCID03</th><th>UTCID04</th><th>UTCID05</th><th>UTCID06</th><th>UTCID07</th></tr>
  <tr><td rowspan="6" class="matrix-section"><b>Condition</b></td><td rowspan="2"><b>Precondition</b></td><td>User id, seat id, start time, and end time are provided</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>Booking depends on user, seat, reservation, and settings repositories</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="3"><b>Mock State (Dependencies)</b></td><td>User and seat exist with valid settings</td><td>O</td><td>O</td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td>Seat or user lookup fails / overlap exists</td><td></td><td></td><td></td><td>O</td><td>O</td><td>O</td><td></td></tr>
  <tr><td>Settings validation or save fails</td><td></td><td></td><td></td><td></td><td></td><td></td><td>O</td></tr>
  <tr><td rowspan="1"><b>Input</b></td><td>Booking time range is valid or invalid</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="5" class="matrix-section"><b>Confirm</b></td><td rowspan="2"><b>Return</b></td><td>Creates reservation with correct seat, user, time range, and initial status</td><td>O</td><td>O</td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td>Overlap-free seat can be booked successfully</td><td>O</td><td>O</td><td>O</td><td></td><td></td><td></td><td></td></tr>
  <tr><td rowspan="2"><b>Exception</b></td><td>Throws validation or not-found exception for invalid rule/seat/user input</td><td></td><td></td><td></td><td>O</td><td>O</td><td>O</td><td></td></tr>
  <tr><td>Repository failure is propagated</td><td></td><td></td><td></td><td></td><td></td><td></td><td>O</td></tr>
  <tr><td rowspan="1"><b>Log message / Interaction</b></td><td>Reservation save, seat sync, and notification side effects execute for success flow</td><td>O</td><td>O</td><td>O</td><td></td><td></td><td></td><td>O</td></tr>
  <tr><td rowspan="4" class="matrix-section"><b>Result</b></td><td colspan="2">Type (N: Normal, A: Abnormal, B: Boundary)</td><td>N</td><td>A</td><td>A</td><td>A</td><td>A</td><td>A</td><td>A</td></tr>
  <tr><td colspan="2">Passed/Failed</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td></tr>
  <tr><td colspan="2">Executed Date</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td></tr>
  <tr><td colspan="2">Defect ID</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
</table>
