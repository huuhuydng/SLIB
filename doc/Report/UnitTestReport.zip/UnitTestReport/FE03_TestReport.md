# Unit Test Report - FE-03: Logout

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr>
    <td><b>Function Code</b></td>
    <td>FE-03</td>
    <td><b>Function Name</b></td>
    <td>FE-03_Logout</td>
  </tr>
  <tr>
    <td><b>Created By</b></td>
    <td>Hadi</td>
    <td><b>Executed By</b></td>
    <td>Hadi</td>
  </tr>
  <tr>
    <td><b>Lines of code</b></td>
    <td>24</td>
    <td><b>Lack of test cases</b></td>
    <td>0</td>
  </tr>
  <tr>
    <td><b>Class Under Test</b></td>
    <td colspan="3">`AuthController.logout(Map&lt;String, String&gt; request)` and `AuthService.logout(String refreshToken)`</td>
  </tr>
  <tr>
    <td><b>Test requirement</b></td>
    <td colspan="3">Verify controller delegation and refresh-token revocation behavior at backend unit-test level.</td>
  </tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr>
    <th>Passed</th>
    <th>Failed</th>
    <th>Untested</th>
    <th>N/A/B</th>
    <th>Total Test Cases</th>
  </tr>
  <tr>
    <td>5</td>
    <td>0</td>
    <td>0</td>
    <td>3 / 2 / 0</td>
    <td>5</td>
  </tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr style="background: #001a8d; color: #ffffff;">
    <th>Section</th>
    <th>Category</th>
    <th>Item</th>
    <th>UTCID01</th>
    <th>UTCID02</th>
    <th>UTCID03</th>
    <th>UTCID04</th>
    <th>UTCID05</th>
  </tr>
  <tr>
    <td rowspan="8" style="background: #001a8d; color: #ffffff;"><b>Condition</b></td>
    <td rowspan="2"><b>Precondition</b></td>
    <td>Logout request object exists</td>
    <td>O</td><td>O</td><td>O</td><td>O</td><td></td>
  </tr>
  <tr>
    <td>Refresh-token revocation is supported by repository layer</td>
    <td>O</td><td></td><td></td><td></td><td>O</td>
  </tr>
  <tr>
    <td rowspan="3"><b>Mock State (Dependencies)</b></td>
    <td>Request contains a non-empty refresh token</td>
    <td>O</td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td>`JwtService.hashToken()` returns hashed token text</td>
    <td></td><td>O</td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td>`JwtService.hashToken()` throws runtime exception</td>
    <td></td><td></td><td></td><td></td><td>O</td>
  </tr>
  <tr>
    <td rowspan="3"><b>Input</b></td>
    <td>Request contains `refreshToken = null`</td>
    <td></td><td></td><td>O</td><td></td><td></td>
  </tr>
  <tr>
    <td>Request contains `refreshToken = ""`</td>
    <td></td><td></td><td></td><td>O</td><td></td>
  </tr>
  <tr>
    <td>Service receives raw refresh token text</td>
    <td></td><td>O</td><td></td><td></td><td>O</td>
  </tr>
  <tr>
    <td rowspan="7" style="background: #001a8d; color: #ffffff;"><b>Confirm</b></td>
    <td rowspan="3"><b>Return</b></td>
    <td>Controller delegates to `authService.logout(refreshToken)` when token is present</td>
    <td>O</td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td>Controller returns success message when refresh token is null</td>
    <td></td><td></td><td>O</td><td></td><td></td>
  </tr>
  <tr>
    <td>Controller returns success message when refresh token is empty</td>
    <td></td><td></td><td></td><td>O</td><td></td>
  </tr>
  <tr>
    <td><b>Exception</b></td>
    <td>Hashing failure is propagated from `AuthService.logout()`</td>
    <td></td><td></td><td></td><td></td><td>O</td>
  </tr>
  <tr>
    <td rowspan="3"><b>Log message / Interaction</b></td>
    <td>`revokeByTokenHash()` is called with hashed token value</td>
    <td></td><td>O</td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td>Service is not called when refresh token is null</td>
    <td></td><td></td><td>O</td><td></td><td></td>
  </tr>
  <tr>
    <td>Service is not called when refresh token is empty</td>
    <td></td><td></td><td></td><td>O</td><td></td>
  </tr>
  <tr>
    <td rowspan="4" style="background: #001a8d; color: #ffffff;"><b>Result</b></td>
    <td colspan="2">Type (N: Normal, A: Abnormal, B: Boundary)</td>
    <td>N</td><td>N</td><td>N</td><td>N</td><td>A</td>
  </tr>
  <tr>
    <td colspan="2">Passed/Failed</td>
    <td>P</td><td>P</td><td>P</td><td>P</td><td>P</td>
  </tr>
  <tr>
    <td colspan="2">Executed Date</td>
    <td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td>
  </tr>
  <tr>
    <td colspan="2">Defect ID</td>
    <td></td><td></td><td></td><td></td><td></td>
  </tr>
</table>
