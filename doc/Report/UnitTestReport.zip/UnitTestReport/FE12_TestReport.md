# Unit Test Report - FE-12: Turn on/Turn off HCE Feature

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><td><b>Function Code</b></td><td>FE-12</td><td><b>Function Name</b></td><td>FE-12_Toggle HCE Feature</td></tr>
  <tr><td><b>Created By</b></td><td>Hadi</td><td><b>Executed By</b></td><td>Hadi</td></tr>
  <tr><td><b>Lines of code</b></td><td>~15</td><td><b>Lack of test cases</b></td><td>0</td></tr>
  <tr><td><b>Class Under Test</b></td><td colspan="3">`UserSettingService.updateSettings(UUID userId, UserSettingDTO dto)`</td></tr>
  <tr><td><b>Test requirement</b></td><td colspan="3">Verify HCE-preference updates through `isHceEnabled`, including partial updates, auto-creation, and persistence behavior.</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr><th>Passed</th><th>Failed</th><th>Untested</th><th>N/A/B</th><th>Total Test Cases</th></tr>
  <tr><td>5</td><td>0</td><td>0</td><td>1 / 4 / 0</td><td>5</td></tr>
</table>

<table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%;">
  <tr style="background: #001a8d; color: #ffffff;"><th>Section</th><th>Category</th><th>Item</th><th>UTCID01</th><th>UTCID02</th><th>UTCID03</th><th>UTCID04</th><th>UTCID05</th></tr>
  <tr><td rowspan="8" style="background: #001a8d; color: #ffffff;"><b>Condition</b></td><td rowspan="2"><b>Precondition</b></td><td>User id and DTO are provided</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>Target field is `isHceEnabled`</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td rowspan="3"><b>Mock State (Dependencies)</b></td><td>`getSettings()` returns existing settings</td><td>O</td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td>`getSettings()` auto-creates default settings</td><td></td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td>Repository save throws runtime exception</td><td></td><td></td><td>O</td><td></td><td>O</td></tr>
  <tr><td rowspan="2"><b>Input</b></td><td>DTO sets `isHceEnabled = false` or `true`</td><td>O</td><td>O</td><td>O</td><td></td><td></td></tr>
  <tr><td>DTO contains `null` HCE field</td><td></td><td></td><td></td><td>O</td><td>O</td></tr>
  <tr><td rowspan="7" style="background: #001a8d; color: #ffffff;"><b>Confirm</b></td><td rowspan="3"><b>Return</b></td><td>HCE flag is updated and returned correctly</td><td>O</td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td>Default settings are created first and then updated</td><td></td><td>O</td><td></td><td></td><td></td></tr>
  <tr><td>Null HCE field leaves current value unchanged</td><td></td><td></td><td></td><td>O</td><td></td></tr>
  <tr><td rowspan="2"><b>Exception</b></td><td>Save failure during update is propagated</td><td></td><td></td><td>O</td><td></td><td></td></tr>
  <tr><td>Save failure after no-op merge is propagated</td><td></td><td></td><td></td><td></td><td>O</td></tr>
  <tr><td rowspan="2"><b>Log message / Interaction</b></td><td>`save()` is called with merged HCE state</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr>
  <tr><td>Other user-setting fields remain unchanged unless DTO provides them</td><td>O</td><td>O</td><td></td><td>O</td><td>O</td></tr>
  <tr><td rowspan="4" style="background: #001a8d; color: #ffffff;"><b>Result</b></td><td colspan="2">Type (N: Normal, A: Abnormal, B: Boundary)</td><td>N</td><td>A</td><td>A</td><td>A</td><td>A</td></tr>
  <tr><td colspan="2">Passed/Failed</td><td>P</td><td>P</td><td>P</td><td>P</td><td>P</td></tr>
  <tr><td colspan="2">Executed Date</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td><td>2026-03-10</td></tr>
  <tr><td colspan="2">Defect ID</td><td></td><td></td><td></td><td></td><td></td></tr>
</table>
